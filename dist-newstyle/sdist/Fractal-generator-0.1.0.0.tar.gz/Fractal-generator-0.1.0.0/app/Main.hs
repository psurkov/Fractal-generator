module Main where

import View

main :: IO ()
main = viewMain