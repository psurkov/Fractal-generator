# Fractal-generator

...

## Install

```bash
git clone https://github.com/psurkov/Fractal-generator.git
cd Fractal-generator
stack setup
stack build
```

## Use

Type `stack run` to start application.